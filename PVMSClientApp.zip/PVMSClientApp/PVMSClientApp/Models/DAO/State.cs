﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PVMSClientApp.Models.DAO
{
    public class State
    {

        public string state_id { get; set; }
        public string state_name { get; set; }
    }
}