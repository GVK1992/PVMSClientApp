﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PVMSClientApp.Models.DAO
{
    public class Visa_type
    {
        public string Occupation { get; set; }
        public string Country { get; set; }
    }
}